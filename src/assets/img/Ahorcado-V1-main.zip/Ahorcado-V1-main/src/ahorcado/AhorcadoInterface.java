package ahorcado;

public interface AhorcadoInterface {

	public String getFrase();
	public String getAdivinado();
	public int aniadeLetra(char letra) throws Exception;
	
}
